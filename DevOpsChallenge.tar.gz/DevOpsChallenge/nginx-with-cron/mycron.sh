#! /bin/sh

echo "mycron" >> /bin/hello.txt

url="http://192.168.43.96:5005/alertAccess"
curl ${url} > /bin/accesslog.txt
