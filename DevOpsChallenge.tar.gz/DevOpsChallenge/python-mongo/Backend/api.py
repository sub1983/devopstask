
from flask import Flask, escape, request, jsonify, redirect
from flask_cors import CORS
import json
from flask_pymongo import PyMongo
from flask_pymongo import ObjectId
from flask_mail import Mail, Message




app = Flask(__name__)
mail = Mail(app)
CORS(app)
app.config["DEBUG"] = True

app.config['MAIL_SERVER']='smtp.gmail.com'
app.config['MAIL_PORT'] = 465
app.config['MAIL_USERNAME'] = '<GMAIL_ID>'
app.config['MAIL_PASSWORD'] = '<GMAIL_PASSWORD>'
app.config['MAIL_USE_TLS'] = False
app.config['MAIL_USE_SSL'] = True
#app.config['AUTHENTICATION'] = 'plain'
mail = Mail(app)


#Database
app.config['MONGO_DBNAME'] = 'devchallenge_app_db:v0'
app.config['MONGO_URI'] = 'mongodb://mongodb:27017/devchallenge_app_db:v0'

mongo = PyMongo(app)


@app.route('/', methods=['GET'])
def home():
    return "<h1>Api is working.</p>"


@app.route('/access-list', methods=['GET'])
def accesslist():
    accessInfo = mongo.db.access
    output = []

    for s in accessInfo.find({}).sort([('_id', -1)]):
        data_obj = {'o_id': str(s['_id']), 'date': s['date'], 'user_agent': s['user_agent'], 'response_code': s['response_code']}
        output.append(data_obj)

    return json.dumps({'result' : output})    

@app.route('/addAccessLog', methods=['POST'])
def addAccessLog():
  todo = mongo.db.access
  print(request.json)
  todo_id = todo.insert_one(request.json)
  return json.dumps({'result' : str(todo_id.inserted_id)})
  #return todo_id.inserted_id

@app.route('/alertAccess', methods=['GET'])
def alertAccess():
    accessInfo = mongo.db.access
    output = []
    accessFailureCount = 0

    for s in accessInfo.find({}).sort([('_id', -1)]):
        data_obj = {'date': s['date'],  'response_code': s['response_code']}
        if s['response_code'] == '401' or s['response_code'] == '404':
            accessFailureCount += 1

        output.append(data_obj)

    if accessFailureCount > 10:
        #send email
        msg = Message("Attempt for UnAuthorized Access",
                sender="subinmat@gmail.com",
                recipients=["subinmat@gmail.com"])
        msg.html = "<b>testing</b>"

        mail.send(msg)              

    return json.dumps({'accessFailureCount': accessFailureCount, 'result' : output})     

     



app.run(host='0.0.0.0')
